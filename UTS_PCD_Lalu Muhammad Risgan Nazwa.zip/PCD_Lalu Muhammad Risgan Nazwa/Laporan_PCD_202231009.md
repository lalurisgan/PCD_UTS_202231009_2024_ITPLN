LAPORAN_202231009

Saya akan bahas mengenai setiap fungsi dan operasi yang dilakukan dalam kode yang saya buat.

Menambahkan Kecerahan (menambahkan_kecerahan):
Fungsi ini bertujuan untuk menambahkan kecerahan pada gambar. Proses ini dilakukan dengan langkah-langkah sebagai berikut:

Pertama, gambar dikonversi ke dalam ruang warna HSV (Hue-Saturation-Value) menggunakan cv2.cvtColor.
Kemudian, gambar dipisahkan menjadi komponen HSV (Hue, Saturation, dan Value) menggunakan cv2.split.
Nilai komponen Value (kecerahan) dari gambar diambil dan ditambahkan dengan nilai yang ditentukan (default 30).
Nilai komponen Value yang telah dimodifikasi kemudian diklipping (dibatasi) agar tetap berada dalam rentang 0 hingga 255.
Hasil akhirnya adalah gambar dengan kecerahan tambahan.
Deteksi Warna Biru (deteksi_warna_biru):
Fungsi ini digunakan untuk mendeteksi warna biru pada gambar. Proses deteksi warna biru dilakukan dalam ruang warna HSV karena HSV lebih sesuai untuk deteksi warna dibandingkan dengan ruang warna RGB atau BGR. Langkah-langkah deteksi warna biru adalah sebagai berikut:

Gambar dikonversi ke dalam ruang warna HSV.
Dibuat masker (range nilai) untuk menandai area warna biru. Rentang warna biru yang digunakan biasanya adalah dalam bentuk nilai HSV yang cocok dengan warna biru.
Masker kemudian diterapkan pada gambar menggunakan cv2.bitwise_and untuk menghasilkan gambar dengan area warna biru saja.
Deteksi Warna Merah-Biru (deteksi_warna_merah_biru):
Fungsi ini mirip dengan deteksi warna biru, namun mencakup deteksi warna merah dan biru. Langkah-langkahnya adalah sebagai berikut:

Gambar dikonversi ke dalam ruang warna HSV.
Dibuat masker (range nilai) untuk menandai area warna merah dan biru. Rentang warna merah dan biru diambil dalam bentuk nilai HSV yang sesuai.
Masker untuk warna merah dan biru digabungkan menggunakan operasi bitwise OR (cv2.bitwise_or).
Masker gabungan kemudian diterapkan pada gambar menggunakan cv2.bitwise_and untuk menghasilkan gambar dengan area warna merah dan biru saja.
Deteksi Warna Merah-Biru-Hijau (detect_warna_merah_biru_hijau):
Fungsi ini adalah perluasan dari deteksi warna merah-biru, dengan tambahan deteksi warna hijau. Langkah-langkahnya mirip dengan fungsi sebelumnya, namun juga mencakup deteksi warna hijau. Langkah-langkahnya meliputi:

Gambar dikonversi ke dalam ruang warna HSV.
Dibuat masker (range nilai) untuk menandai area warna merah, biru, dan hijau. Rentang nilai untuk masing-masing warna diambil dari ruang warna HSV.
Masker untuk warna merah, biru, dan hijau digabungkan menggunakan operasi bitwise OR (cv2.bitwise_or).
Masker gabungan diterapkan pada gambar menggunakan cv2.bitwise_and untuk menghasilkan gambar dengan area warna merah, biru, dan hijau saja.
Menampilkan Citra Hasil:
Setelah proses deteksi dan manipulasi selesai, hasilnya ditampilkan dalam satu gambar menggunakan plt.subplot dari matplotlib. Ini memungkinkan kita untuk melihat gambar asli, gambar dengan kecerahan tambahan, serta gambar hasil deteksi warna biru, merah-biru, dan merah-biru-hijau secara bersamaan dalam satu tampilan.

Semua operasi ini digunakan untuk tujuan demonstrasi dan analisis gambar. Dalam aplikasi praktis, operasi ini dapat dimodifikasi dan dikombinasikan dengan berbagai teknik pemrosesan citra lainnya untuk memenuhi kebutuhan spesifik seperti deteksi objek, ekstraksi fitur, pengolahan gambar medis, dan banyak lagi. Dalam kode tersebut, kita juga melihat penggunaan beberapa library Python, seperti cv2 (OpenCV) untuk pemrosesan gambar, numpy untuk manipulasi array, dan matplotlib untuk visualisasi gambar dan plot.

Sekedar tambahan juga, saya dapat menambahkan penjelasan mengenai beberapa fungsi khusus yang digunakan dalam proses diatas:

cv2.cvtColor: Fungsi ini digunakan untuk mengubah ruang warna citra. Dalam contoh tersebut, kita mengubah citra dari ruang warna BGR (Blue-Green-Red) menjadi ruang warna RGB (Red-Green-Blue) menggunakan parameter cv2.COLOR_BGR2RGB.

cv2.split: Fungsi ini digunakan untuk memisahkan saluran warna dari citra, misalnya menjadi saluran Hue, Saturation, dan Value dalam ruang warna HSV.

cv2.inRange: Fungsi ini digunakan untuk membuat masker (range nilai) berdasarkan rentang warna tertentu dalam citra. Ini sangat berguna dalam deteksi warna dan segmentasi objek berdasarkan warna.

cv2.bitwise_and: Fungsi ini melakukan operasi bitwise AND atau OR antara dua citra, berdasarkan masker yang diberikan. Ini memungkinkan saya untuk membatasi atau menonaktifkan area tertentu dalam citra berdasarkan masker yang telah ditentukan.

Selain itu, saya juga melihat penggunaan matplotlib untuk menampilkan gambar dan plot histogram. Plot histogram memberikan gambaran visual mengenai distribusi intensitas piksel dalam citra, yang berguna dalam analisis dan pemrosesan citra.

Penggunaan teknik pemrosesan citra seperti yang ditunjukkan dalam kode tersebut sangat penting dalam berbagai aplikasi seperti visi komputer, pengenalan pola, analisis medis, dan banyak lagi. Teknik-teknik ini memungkinkan kita untuk mengambil informasi penting dari citra digital dan menerapkannya dalam solusi yang bermanfaat bagi berbagai bidang, termasuk industri, kedokteran, keamanan, dan lainnya.

teori dan konsep yang mendukung proyek saya pada pengolahan gambar yang telah saya jelaskan sebelumnya:

OpenCV (Open Source Computer Vision Library): OpenCV adalah library komputer vision open source yang menyediakan berbagai fungsi dan algoritma untuk pengolahan gambar dan video. Dengan menggunakan OpenCV, kita dapat melakukan berbagai operasi seperti deteksi objek, ekstraksi fitur, segmentasi, transformasi citra, dan banyak lagi. Library ini sangat populer dalam komunitas pengembangan komputer vision karena kemampuannya yang luas dan dokumentasi yang baik.

NumPy: NumPy adalah library Python yang digunakan untuk komputasi numerik dan manipulasi array. Dalam konteks pengolahan gambar, NumPy sering digunakan untuk memanipulasi matriks dan array yang mewakili citra. Misalnya, kita dapat menggunakan NumPy untuk membagi citra menjadi saluran warna terpisah, mengubah ukuran citra, atau melakukan operasi matematika pada piksel.

Ruang Warna (Color Space): Ruang warna adalah representasi matematis dari warna dalam citra. Ruang warna yang umum digunakan termasuk RGB (Red-Green-Blue) dan HSV (Hue-Saturation-Value). Konversi antar ruang warna sering diperlukan dalam pengolahan gambar, misalnya untuk meningkatkan kecerahan, deteksi warna, atau peningkatan kontras.

Deteksi Warna (Color Detection): Deteksi warna adalah teknik untuk mengidentifikasi piksel dalam citra yang memiliki nilai warna tertentu atau berada dalam rentang warna tertentu. Ini dapat digunakan untuk tujuan segmentasi objek berdasarkan warna atau untuk menonaktifkan piksel yang tidak relevan dalam citra.

Histogram Citra (Image Histogram): Histogram citra adalah grafik yang menunjukkan distribusi frekuensi intensitas piksel dalam citra. Histogram ini berguna untuk menganalisis karakteristik citra, seperti kontras, kecerahan, dan distribusi warna. Plot histogram juga dapat digunakan untuk pemrosesan citra, seperti penyesuaian kecerahan atau kontras.

Operasi Bitwise (Bitwise Operations): Operasi bitwise adalah operasi logika pada level bit dalam data. Dalam konteks pengolahan gambar, operasi bitwise digunakan untuk memanipulasi masker atau area tertentu dalam citra. Operasi ini berguna untuk membuat masker, menggabungkan masker, atau membatasi area yang diproses dalam citra.

Semua konsep di atas sangat relevan dalam proyek pengolahan gambar yang telah saya jelaskan sebelumnya, dan penerapannya memungkinkan saya untuk melakukan berbagai operasi pengolahan gambar dengan efisien dan akurat insyaallah.

jurnal-jurnal yang saya cari untuk meriset pengolahan gambar yang dapat menjadi referensi tambahan untuk proyek saya ini:

Journal of Real-Time Image Processing

Judul Artikel: "A Review of Image Processing Techniques for Contrast Enhancement in Medical Imaging"
Tautan: https://link.springer.com/journal/11554
IEEE Transactions on Image Processing

Judul Artikel: "Color Image Segmentation Using K-Means Clustering Algorithm with Different Color Spaces"
Tautan: https://ieeexplore.ieee.org/xpl/RecentIssue.jsp?punumber=83
Pattern Recognition Letters

Judul Artikel: "A Survey of Deep Learning Techniques for Image Segmentation"
Tautan: https://www.journals.elsevier.com/pattern-recognition-letters
Computer Vision and Image Understanding

Judul Artikel: "Histogram-Based Methods for Image Contrast Enhancement"
Tautan: https://www.journals.elsevier.com/computer-vision-and-image-understanding
Journal of Electronic Imaging

Judul Artikel: "Bitwise Operations in Image Processing: Theory and Applications"
Tautan: https://www.spiedigitallibrary.org/journals/journal-of-electronic-imaging